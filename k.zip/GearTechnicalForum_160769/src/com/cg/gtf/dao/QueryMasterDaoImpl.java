package com.cg.gtf.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository("querymasterdao")
public class QueryMasterDaoImpl implements IQueryMasterDao{

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public int searchId(int Id) {
		// TODO Auto-generated method stub
		return 0;
	}

}
