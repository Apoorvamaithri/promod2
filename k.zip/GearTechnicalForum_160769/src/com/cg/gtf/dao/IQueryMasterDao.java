package com.cg.gtf.dao;

public interface IQueryMasterDao {
	
	public int searchId(int Id);
}
