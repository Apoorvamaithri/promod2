package com.cg.gtf.service;

public interface IQueryMasterService {
	public int searchId(int Id);
}
